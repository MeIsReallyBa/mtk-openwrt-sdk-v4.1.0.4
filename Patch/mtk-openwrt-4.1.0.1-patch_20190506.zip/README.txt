Release Note
=======================
mtk-openwrt-4.1.0.1-patch_20190506.tar.xz is a SDK patch for 7622/7629 MAP supporting

How to apply?
=======================
To apply the patch, move the patch to SDK root and untar
$ cp mtk-openwrt-4.1.0.1-patch_20190506.tar.xz mtk-openwrt-4.1.0.0
$ cd mtk-openwrt-4.1.0.0
$ tar Jxvf mtk-openwrt-4.1.0.1-patch_20190506.tar.xz